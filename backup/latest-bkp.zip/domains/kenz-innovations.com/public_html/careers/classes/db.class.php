
<?php


require_once('db.php');
            $db   = new DbConnect();
            $conn = $db->connect();

            ?>