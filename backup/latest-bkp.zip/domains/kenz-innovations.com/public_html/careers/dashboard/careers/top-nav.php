<?php
$page= basename($_SERVER['PHP_SELF']);
?>
<div class="top_bar_new mb-0" style="background: white;">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12"  style="padding:10px">
				<span>
				<!--	<p class="float-right p-t-10"><a href="login.php" class="reset-anchor mr-3"><i class="fas fa-user mx-2"></i> Login</a></p>  -->
					<center>
						<a href="index.php" class="reset-anchor">
							<img src="images/kenz-logo1.png" style="width:140px;">
						</a>
					</center>
				</span>
			</div>
		</div>
	</div>
</div>