<!DOCTYPE HTML>
<html lang="eng">
<head>
<title>Kenz-innovations - Apply Online</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/esdy.css" rel='stylesheet' type='text/css' />
<link href="css/fontawesome-all.min.css" rel="stylesheet">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body>