<?php
include 'headers.php';
include('classes/posts.php');
include 'top-nav.php';
// include 'navigation.php';
 ?>
<div style="height: 120px;background-image: url(https://changan.com.pk/wp-content/uploads/2018/10/careers-bg.jpg);background-size: cover;background-repeat: no-repeat;">
    
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                
                <h3 style="padding-top:30px">Current Openings at our Partner Dealership</h3>
                
            </div>
            
        </div>
    </div>
    
</div>
<div class="container" style="margin-top:10px;">
    
	<div class="row justify-content-center">
	    
		<div class="col-md-12">
			
		 	<div class="rounded">
		   		<p><i class="fas fa-check-circle"></i> Your application has been successfully submitted. Thank You.</p>
        	</div>
			
			
		</div>
	</div>
</div>
	
	


  

	<script type="text/javascript" src="../js/bootstrap.js "></script>
</body>
</html>