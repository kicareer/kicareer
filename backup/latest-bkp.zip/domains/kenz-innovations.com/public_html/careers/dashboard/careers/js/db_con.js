db_con="http://127.0.0.1/projects/jasaf/incomming-connection/";
home_dir="http://127.0.0.1/projects/jasaf/";