<?php
$page= basename($_SERVER['PHP_SELF']);
?>


<div style="height: 120px;background-image: url(https://changan.com.pk/wp-content/uploads/2018/10/careers-bg.jpg);background-size: cover;background-repeat: no-repeat;">
    
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                
                <h3 style="padding-top:30px">Current Openings at our Partner Dealership</h3>
                
            </div>
            
        </div>
    </div>
    
</div>
<div class="header-section" style="background: #fff;padding:10px;margin-top:20px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3>We are looking for qualified and energetic individuals to join our Partner Dealerships in the following cities:</h3>
                <center><p> 
<span style="color:blue;padding:0px 5px">Karachi</span> | 
<span style="color:blue;padding:0px 5px">Hyderabad</span> | 
<span style="color:blue;padding:0px 5px">Sukkur</span> | 
<span style="color:blue;padding:0px 5px">Quetta</span> | 
<span style="color:blue;padding:0px 5px">Bahawalpur</span> | 
<span style="color:blue;padding:0px 5px">Multan</span> | 
<span style="color:blue;padding:0px 5px">Sahiwal</span> | 
<span style="color:blue;padding:0px 5px">Faisalabad</span> | 
<span style="color:blue;padding:0px 5px">Lahore</span> | 
<span style="color:blue;padding:0px 5px">Sargodha</span> | 
<span style="color:blue;padding:0px 5px">Jhelum</span> | 
<span style="color:blue;padding:0px 5px">Rawalpindi</span> | 
<span style="color:blue;padding:0px 5px">Islamabad</span> | 
<span style="color:blue;padding:0px 5px">Peshawar</span> | 
<span style="color:blue;padding:0px 5px">Mansehra</span> | 
<span style="color:blue;padding:0px 5px">Sialkot</span> | 
<span style="color:blue;padding:0px 5px">Okara</span>
</p></center>
            </div>
        </div>
    </div>    
</div>