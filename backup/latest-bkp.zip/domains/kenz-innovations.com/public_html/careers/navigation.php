<?php
$page= basename($_SERVER['PHP_SELF']);
?>


<div style="height: 120px;background-image: url(https://changan.com.pk/wp-content/uploads/2018/10/careers-bg.jpg);background-size: cover;background-repeat: no-repeat;">
    
    <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                
                <h3 style="padding-top:40px">Current opening in KENZ GROUP</h3>
                
            </div>
            
        </div>
    </div>
    
</div>
<div class="header-section" style="background: #fff;padding:10px;margin-top:20px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3></h3>
                <center><p> 
<span style="color:blue;padding:0px 5px">Saudi Arabia</span> | 
<span style="color:blue;padding:0px 5px">India</span> | 
<span style="color:blue;padding:0px 5px">Pakistan</span> | 
<span style="color:blue;padding:0px 5px">Australia</span> | 
<span style="color:blue;padding:0px 5px">New Zealand</span> | 
<span style="color:blue;padding:0px 5px">Canada</span>
</p></center>
            </div>
        </div>
    </div>    
</div>